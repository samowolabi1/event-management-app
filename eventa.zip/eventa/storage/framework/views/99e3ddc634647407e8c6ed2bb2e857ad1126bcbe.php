<?php $__env->startSection('content'); ?>




<div class="row" style="padding:19px;">

<div class="col-md-6">
<p style="text-align:center; margin-bottom:10px;" class="h3 text-primary">Create Events</p>

<?php echo Form::open(['action' => 'eventsController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

  
  <div class="form-group">
    <?php echo e(Form::label('category', 'Event Category',['class'=>'createlabel'])); ?>

    <?php echo e(Form::select('type', ['anniversary'=>'Anniversary','birthday'=>'Birthday','comedy' => 'Comedy Shows','education' => 'Educational','funeral'=>'Funeral','musical' => 'Musical','party'=>'House Party','religious' => 'Religious','seminar' => 'Seminar','wedding' => 'Wedding','workshop' => 'Workshop'], 'null',['class' => 'custom-select','placeholder' => 'Select Category','required' => 'required','autofocus' => 'autofocus'])); ?>

  
  </div>

  <div class="form-group">
    <?php echo e(Form::label('state', 'State',['class'=>'createlabel'])); ?>

    <?php echo e(Form::select('state', ['abia'=>'Abia','adamawa'=>'Adamawa','anambra' => 'Anambra','education' => 'Educational','funeral'=>'Funeral','musical' => 'Musical','party'=>'House Party','religious' => 'Religious','seminar' => 'Seminar','wedding' => 'Wedding','workshop' => 'Workshop'], 'null',['class' => 'custom-select','placeholder' => 'Select Event State'])); ?>

  
  </div>

   <div class="form-group">
    <?php echo e(Form::label('date', 'Event Date',['class' => 'createlabel','required' => 'required','autofocus' => 'autofocus'])); ?>

    <?php echo e(Form::date('date', \Carbon\Carbon::now(), ['class' => 'form-control'])); ?>

  
  </div>

     <div class="form-group">
    <?php echo e(Form::label('time', 'Event Time',['class' => 'createlabel','required' => 'required','autofocus' => 'autofocus'])); ?>

    <?php echo e(Form::time('time', Carbon\Carbon::now()->format('H:i'))); ?>

  
  </div>


  <div class="form-group">
    <?php echo e(Form::label('organiser', 'Event Organiser',['class'=>'createlabel'])); ?>

    <?php echo e(Form::text('organiser', '',['class' => 'form-control','placeholder' => 'Company, Individual or Group Name','required' => 'required','autofocus' => 'autofocus'])); ?>

  
  </div>

  <div class="form-group">
    <?php echo e(Form::label('address', 'Full Address',['class'=>'createlabel'])); ?>

    <?php echo e(Form::text('address', '',['class' => 'form-control','placeholder' => 'Descriptive Full Address','required' => 'required','autofocus' => 'autofocus'])); ?>

  
  </div>

  <div class="form-group">
    <?php echo e(Form::label('theme', 'Event Theme',['class'=>'createlabel'])); ?>

    <?php echo e(Form::text('theme', '',['class' => 'form-control','placeholder' => 'This is the title on the homepage','required' => 'required','autofocus' => 'autofocus','maxlength' => 34])); ?>

  
  </div>

  <div class="form-group">
    <?php echo e(Form::label('topic', 'Topic',['class'=>'createlabel'])); ?>

    <?php echo e(Form::text('topic', '',['class' => 'form-control','placeholder' => 'A subheading that relates to the theme','required' => 'required','autofocus' => 'autofocus'])); ?>

  
  </div>

  <div class="form-group">
    <?php echo e(Form::label('speakers', 'Speakers',['class'=>'createlabel'])); ?>

    <?php echo e(Form::text('speakers', '',['class' => 'form-control','placeholder' => 'Speaker one, Speaker two, ...','required' => 'required','autofocus' => 'autofocus'])); ?>

    <small id="passwordHelpBlock" class="form-text text-muted">
    Enter the speakers name, special appearance or special guest at the event
    </small>
  </div>

  <div class="form-group">
    <?php echo e(Form::label('rsvp', 'RSVP',['class'=>'createlabel'])); ?>

    <?php echo e(Form::text('rsvp', '',['class' => 'form-control','placeholder' => 'Name, 080839933....','required' => 'required','autofocus' => 'autofocus'])); ?>

    <small id="passwordHelpBlock" class="form-text text-muted">
    Enter names and contact for RSVP
    </small>
  </div>

  
  <div class="form-group">
    <?php echo e(Form::label('gatefee', 'Gate Fee',['class'=>'createlabel'])); ?>

    <?php echo e(Form::text('gatefee', 'Free',['class' => 'form-control','placeholder'=>'Free'])); ?>

  </div>

  <div class="form-group">
    <?php echo e(Form::label('banner')); ?><br>
    <?php echo e(Form::file('banner')); ?>

    <small id="passwordHelpBlock" class="form-text text-muted">
    Handbill or image of size 590px by 300px
    </small>
  </div><br>
  
  <div class="form-group">
    <?php echo e(Form::label('otherinfo', 'Other Information',['class'=>'createlabel'])); ?>

    <?php echo e(Form::textarea('otherinfo', '',['id' => 'article-ckeditor', 'class' => 'form-control','placeholder' => '   More information about the event'])); ?>

  
  </div>
    <?php echo e(Form::submit('submit',['class'=>'btn btn-lg btn-outline-primary pull-right'])); ?>



<?php echo Form::close(); ?>


</div>

<div class="col-md-6">

</div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>