<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Welcome to your Dashboard</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <a href="/events/create" class="btn btn-primary">Create Events</a>
                    <hr style="margin:10px 0px 10px 0px;">


                  
                <?php if(count($even) > 0): ?>
                    <table class="table table-striped">
                    <tr>
                        <td style="color:#0091dc;">Event Theme</td>
                        <td style="color:#0091dc;">Event Topic</td>
                        <td></td>
                    
                    </tr>
                    <?php $__currentLoopData = $even; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($event->theme); ?></td>
                            <td><?php echo e($event->topic); ?></td>
                            <td><a href="/events/<?php echo e($event->id); ?>/edit" class="btn btn-default">Edit</a></td>
                            
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                    <?php else: ?>
                        <p>You have not created any event</p>
                    <?php endif; ?> 

                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>