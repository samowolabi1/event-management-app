<?php $__env->startSection('content'); ?>


<div class="row" style="padding:19px;">

<div class="col-md-6">
<p style="text-align:center; margin-bottom:10px;" class="h3 text-primary">Edit Event</p>

<?php echo Form::open(['action' => ['eventsController@update', $event->id], 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

  

  <div class="form-group">
    <?php echo e(Form::label('organiser', 'Event Organiser')); ?>

    <?php echo e(Form::text('organiser', $event->organiser,['class' => 'form-control','required' => 'required','autofocus' => 'autofocus'])); ?>

  
  </div>

  <div class="form-group">
    <?php echo e(Form::label('address', 'Full Address')); ?>

    <?php echo e(Form::text('address', $event->address,['class' => 'form-control','required' => 'required','autofocus' => 'autofocus'])); ?>

  
  </div>

  <div class="form-group">
    <?php echo e(Form::label('theme', 'Event Theme')); ?>

    <?php echo e(Form::text('theme', $event->theme,['class' => 'form-control','required' => 'required','autofocus' => 'autofocus'])); ?>

  
  </div>

  <div class="form-group">
    <?php echo e(Form::label('topic', 'Topic')); ?>

    <?php echo e(Form::text('topic',$event->topic,['class' => 'form-control','required' => 'required','autofocus' => 'autofocus'])); ?>

  
  </div>

  <div class="form-group">
    <?php echo e(Form::label('speakers', 'Speakers')); ?>

    <?php echo e(Form::text('speakers', $event->speakers,['class' => 'form-control','required' => 'required','autofocus' => 'autofocus'])); ?>

    <small id="passwordHelpBlock" class="form-text text-muted">
    Enter the speakers name, special appearance or special guest at the event
    </small>
  </div>

  <div class="form-group">
    <?php echo e(Form::label('rsvp', 'RSVP')); ?>

    <?php echo e(Form::text('rsvp', $event->rsvp,['class' => 'form-control','required' => 'required','autofocus' => 'autofocus'])); ?>

    <small id="passwordHelpBlock" class="form-text text-muted">
    Enter names and contact for RSVP
    </small>
  </div>

  
  <div class="form-group">
    <?php echo e(Form::label('gatefee', 'Gate Fee')); ?>

    <?php echo e(Form::text('gatefee', $event->gatefee,['class' => 'form-control'])); ?>

  </div>

  <div class="form-group">
    <?php echo e(Form::label('banner')); ?><br>
    <?php echo e(Form::file('banner')); ?>

  </div><br>
  
  <div class="form-group">
    <?php echo e(Form::label('otherinfo', 'Other Information')); ?>

    <?php echo e(Form::textarea('otherinfo',$event->otherinfo,['id' => 'article-ckeditor', 'class' => 'form-control'])); ?>

  
  </div>
    <?php echo e(Form::hidden('_method','PUT')); ?>

    <?php echo e(Form::submit('submit',['class'=>'btn btn-lg btn-outline-primary pull-right'])); ?>



<?php echo Form::close(); ?>


</div>

<div class="col-md-6">

</div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>