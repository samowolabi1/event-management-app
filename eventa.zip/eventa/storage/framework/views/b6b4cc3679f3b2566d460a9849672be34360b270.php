<?php $__env->startSection('content'); ?>

<a href="<?php echo e(URL::previous()); ?>"><button class="btn btn-info">Go Back</button></a>

<p style="text-align:center; margin-bottom:10px;" class="h3 text-primary"></p>


<div class="well">
<div class="row" style="padding:19px;">


<div class="col-md-4 col-sm-4">

  <img style="width:300px; height:300px;" class="rounded image-fluid" src="/storage/banners/<?php echo e($event->banner); ?>" alt="Event Banner Image">
  

</div>

<div class="col-md-8 col-sm-8">


              <h4 class="card-title">
                <p><?php echo e($event->theme); ?></p>
              </h4>
              <p class="card-text text-bold "><span class="text-primary">Category:</span> <?php echo e($event->type); ?></p>
              <p class="card-text"><span class="text-primary">Date:</span> <?php echo e($event->date); ?> | <span class="text-primary">Time:</span> <?php echo e($event->time); ?> | <span class="text-primary">Gate Fee:</span> <?php echo e($event->gatefee); ?></p>
              <p class="card-text"><span class="text-primary">State:</span> <?php echo e($event->state); ?> | <span class="text-primary">Full Address:</span>: <?php echo e($event->address); ?></p>
              <p class="card-text"><span class="text-primary">RSVP:</span> <?php echo e($event->rsvp); ?></p>
              <p class="card-text"><span class="text-primary">Organiser:</span> <?php echo e($event->organiser); ?></p>
              <p class="card-text"><span class="text-primary">Sub Heading:</span> <?php echo e($event->topic); ?></p>
              <p class="card-text"><span class="text-primary">Other Information:</span> <?php echo e($event->otherinfo); ?></p>

</div>


</div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>