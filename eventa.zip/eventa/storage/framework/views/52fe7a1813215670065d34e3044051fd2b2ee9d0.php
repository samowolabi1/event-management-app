<?php $__env->startSection('content'); ?>

   
 


<?php $__currentLoopData = $events->chunk(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eventchunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="row boxpad">
  <?php $__currentLoopData = $eventchunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="col-lg-3 col-md-4 col-sm-6 portfolio-item">
          <div class="card h-100 text-center">
            <a href="#"><img style="width:300px; height:280px;" class="card-img-top" src="/storage/banners/<?php echo e($event->banner); ?>" alt="Event Banner Image"></a>
            <div class="card-body">
              <h2 class="font-weight-bold indigo-text mb-3">
                <?php echo e($event->theme); ?>

              </h2>
              <p class="h5">Category: <?php echo e($event->type); ?></p>
              <p class="h5"><i class="fa fa-calendar"></i>   <?php echo e($event->date); ?></p>
              <p class="h5"><i class="fa fa-map-marker"></i>   <?php echo e($event->state); ?></p>
              <p class="h5">Organiser: <?php echo e($event->organiser); ?></p>
              <p style="text-align:center;"><button class="btn"><a href="/events/<?php echo e($event->id); ?>">More Details</a></button></p>
            </div>
          </div>
        </div>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <!-- /.row -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>