@extends('layouts.app')

@section('content')

<button class="btn btn-danger">Click Me</button>



 <h1>Contact Us Page</h1>

    <!-- Footer -->



    

@endsection