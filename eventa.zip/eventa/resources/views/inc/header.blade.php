
 <link href="{{ URL::to('css/textslide.css') }}" rel="stylesheet">

<div>
<header class="masthead" style="background-image: url('img/home-bg.jpg')">
      <div class="overlay"></div>
      <div class="container">
        <div class="row">
          <div class="col-lg-8 col-md-10 mx-auto">
            <div class="site-heading">
              <h1>Eventa</h1>
              <span class="item-1">Showcasing naija shows and events to the world </span>
              <span class="item-2">2 Showcasing naija shows and events to the world  </span>
              <span class="item-3">3 Showcasing naija shows and events to the world </span>
            </div>
          </div>
        </div>
      </div>
    </header>
</div>