$(document).ready(function(){

    $('#hello').click(function(){
        alert('welcome to jquery');
    });

});